function createCard(title, cName, views, monthsOld, duration, thumbnail){
    //Finish this function
    let viewsStr
    if (views<1000000){
         viewsStr = views/1000 + "K";
    }
    else if (views>1000000){
         viewsStr = views/1000000 + "M";
    }
    else{
         viewsStr = views/1000 + "K";   
    }
    let html = ` <div class="card">
    <div class="img">
        <img src="https://i.ytimg.com/vi/UzYRQURh_pY/hqdefault.jpg?sqp=-oaymwEbCKgBEF5IVfKriqkDDggBFQAAiEIYAXABwAEG&rs=AOn4CLCqIwQwDx1EIDwleUS2D1CGiar3LQ"
            alt="">
    </div>
    <div class="text">
        <h2>${title}</h2>
        <p>${cName} . ${viewsStr} views . 2 months ago</p>
    </div>
</div>`
}