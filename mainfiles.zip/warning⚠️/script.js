var typed = new Typed(".auto-type", {
    strings : ["Programmer", "Developer", "Hacker"],
    typeSpeed : 150,
    backSpeed : 150,
    loop : true
})